# Slony Lag Monitor #

## Description 
This monitors how far behind Slony replication is between nodes.

## Purpose 
The purpose of Slony is to allow replication of a subset of tables for reporting.  During reporting/querying Slony let the queries finish in order to ensure the queried results are in a consistent state.  As such, occasionally, a simple count on tables can yield a difference between source and destination.

There are records that show on both sides when a record was sent, and when it was received.  Comparing the two tables will give us an estimate as to how far off the replication is.

Through the configuration file, a threshold can be set (see man page on /etc/slony-lag-monitor.conf)

The initial directions from Postgres on how to set up replication skips around the usage of slon_tools.conf to configure replication.  This application relies on it. It is __strongly__ advised you have this setup and tested thoroughly prior to using this tool.
