# written for perl
#
# Author: Dwayne Randle
#

my $lag_seconds =query_lag_status($NODE_NUM);
my $is_lagging = is_lag_behind($NODE_NUM);

print "Status = $lag_seconds\n" if ($RUN_ONCE);
print "Behind = $is_lagging\n" if ($RUN_ONCE);


# $last_lag keeps the time since it last detecting lagging.
# This could be useful for total amount of lag free time.
# Potential for trending.
my $last_lag = time; # thought this is funny "my last laugh"
my $lagging_start_time = 0;

my $alarm_triggered_time = 0;
my $last_alarm_exec_time = 0;
my $reset_alarm_interval = $CLEAR_INTERVAL * 60;
my $alarm_interval       = $ALARM_INTERVAL * 60;

my %parameters = (
  'is_lag_behind'      => \&is_lag_behind,
  'is_lagging_behind'  => \&is_lagging_behind,
  'lagging_start_time' => \&lagging_start_time,
);

sub query_lag_status {
  my ($nodenum) = @_;

  my $query = qq{
    select
      -- max(ev_timestamp) - max(con_timestamp) as lag
      extract(epoch from (max(ev_timestamp))) - extract(epoch from max(con_timestamp)) as lag
      from "_$CLUSTER_NAME".sl_event,
           "_$CLUSTER_NAME".sl_confirm
  };

  #print $query ."\n";

  my ($port, $host, $dbname, $dbuser)= ($PORT[$nodenum], $HOST[$nodenum], $DBNAME[$nodenum], $USER[$nodenum]);
  my $result=`/usr/pgsql-9.1/bin/psql -p $port -h $host -U $dbuser -c "$query" --tuples-only $dbname`;
  chomp $result;
  $result =~ s/[\n\s]//g;
  #$result = substr($result,0,8);

  #print "Query was: $query\n";
  #print "Result was: [$result]\n";

  return $result;
}

sub is_lag_behind {
  my($nodenum) = @_;
  my $lag = query_lag_status($nodenum);

  my $result = false;
  $result = true if ($lag > $LAG_TIME_THRESHOLD);

  #print "[$lag] and [$LAG_TIME_THRESHOLD]\n";
  #print "results are $result \n";

  return $result;
}

sub is_lagging_behind {
  my($nodenum) = @_;
  my $lagging = is_lag_behind($nodenum);

  return 1 if ($lagging);

  return 0;
}

sub send_alarms() {
  if ( $is_lagging ) {
    print "checking alarms to send\n" if ($DEBUG);
    unless(($alarm_triggered_time) || ((time-$alarm_triggered_time) < $alarm_interval)) {
      my $param = $parameters{$EXEC_PARAMS}->($NODE_NUM);
      my $output = qx/$EXEC_PROGRAM $param/;
      print "$output\n", if ($DEBUG);
      $alarm_triggered_time = time;
    }
  }
  return 1;
}


sub detect_lagging {
  $is_lagging = is_lag_behind($NODE_NUM);
  $last_lag = time if $is_lagging;

  print "start = $lagging_start_time lagging $is_lagging\n" if ($DEBUG);

  if(($lagging_start_time == 0) && ($is_lagging) && ($last_lag >0)) {
    $lagging_start_time = time;
    $last_lag = 0;
    print "lagging detected\n" if ($DEBUG);
  }
  return $is_lagging;
}

sub clear_alarms {
  if ($alarm_triggered_time) {
    unless( $is_lagging) {
      my $lag_free_time = time - $last_lag;
      if ($lag_free_time > $reset_alarm_interval) {
        $lagging_start_time = 0;
        $last_lag = 0;

        $alarm_triggered_time = 0;
        $last_alarm_exec_time = 0;

        my $param = $parameters{$EXEC_PARAMS}->($NODE_NUM);
        my $output = qx/$EXEC_PROGRAM $param/;
        print "$output\n", if ($DEBUG);     
      }
    }
  }
  return 1;
}

# Do not edit anything below this line
#
1;

